#!/bin/bash

usage() { echo "Usage: $0 [-a <adjective>] [-n <noun>] [-v <verb (present tense)>]" 1>&2; exit; }

while getopts ":a:n:v:" o; do
    case "${o}" in
        a)
            a=${OPTARG}
            ;;
        n)
            n=${OPTARG}
            ;;
        v)
            v=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${a}" ] || [ -z "${n}" ] || [ -s "${v}" ]; then
    usage
fi

madlib="The "${a}" "${n}" "${v}" on the computer."

echo -e "My Mad Lib:\n$madlib"
echo "$madlib" > madlib.txt

